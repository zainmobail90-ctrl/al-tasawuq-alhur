plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.altasawuq.alhur"
    compileSdk = flutter.compileSdkVersion

    defaultConfig {
        applicationId = "com.altasawuq.alhur"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = 1
        versionName = "1.0"
    }
}

flutter {
    source = "../.."
}
