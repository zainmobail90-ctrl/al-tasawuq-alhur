package com.altasawuq.alhur

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
