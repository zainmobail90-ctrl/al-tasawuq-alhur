# التسوق الحر

تطبيق دليفري بدون كتالوج منتجات:
الزبون يكتب طلبه بحرية، يضع عنوان التوصيل، ويختار الدفع نقداً أو إلكترونياً.

## التشغيل
1. ثبّت Flutter وAndroid Studio.
2. أنشئ مشروع Firebase.
3. فعّل Phone Authentication وFirestore.
4. ثبّت FlutterFire CLI.
5. داخل المشروع نفّذ:
   flutterfire configure
6. ثم:
   flutter pub get
   flutter run

## ملاحظة
الدفع الإلكتروني يحتاج ربط بوابة دفع عراقية لاحقاً.
لوحة السائق/المدير ستأتي في المرحلة التالية.
